/**
 * ============================================
 * API MODULE
 * ============================================
 * 
 * This module handles all HTTP requests to the json-server API.
 * It provides a centralized way to communicate with the backend.
 * 
 * All methods use async/await and try...catch for error handling.
 */

const API = {
    /**
     * Base URL for API requests
     */
    baseURL: CONFIG.API_URL,

    /**
     * Generic fetch wrapper with error handling
     * @param {string} url - API endpoint URL
     * @param {object} options - Fetch options (method, headers, body, etc.)
     * @returns {Promise<any>} Response data
     * @throws {Error} If request fails
     */
    async request(url, options = {}) {
        try {
            // Set default headers
            const headers = {
                'Content-Type': 'application/json',
                ...options.headers
            };

            // Make the request
            const response = await fetch(url, {
                ...options,
                headers
            });

            // Check if response is ok
            if (!response.ok) {
                throw new Error(`HTTP Error ${response.status}: ${response.statusText}`);
            }

            // Parse JSON response
            const data = await response.json();
            return data;

        } catch (error) {
            console.error('❌ API Request failed:', error);
            
            // Check if it's a network error
            if (error.message.includes('Failed to fetch')) {
                throw new Error('Cannot connect to server. Please make sure json-server is running.');
            }
            
            throw error;
        }
    },

    /**
     * GET request - Retrieve data
     * @param {string} endpoint - API endpoint (e.g., '/users')
     * @param {object} params - Query parameters
     * @returns {Promise<any>} Response data
     */
    async get(endpoint, params = {}) {
        try {
            // Build URL with query parameters
            const url = new URL(this.baseURL + endpoint);
            Object.keys(params).forEach(key => 
                url.searchParams.append(key, params[key])
            );

            console.log('📡 GET Request:', url.toString());

            const data = await this.request(url.toString(), {
                method: 'GET'
            });

            console.log('✅ GET Response:', data);
            return data;

        } catch (error) {
            console.error('❌ GET Error:', error);
            throw error;
        }
    },

    /**
     * POST request - Create new data
     * @param {string} endpoint - API endpoint
     * @param {object} data - Data to send
     * @returns {Promise<any>} Created resource
     */
    async post(endpoint, data) {
        try {
            const url = this.baseURL + endpoint;
            console.log('📡 POST Request:', url, data);

            const response = await this.request(url, {
                method: 'POST',
                body: JSON.stringify(data)
            });

            console.log('✅ POST Response:', response);
            return response;

        } catch (error) {
            console.error('❌ POST Error:', error);
            throw error;
        }
    },

    /**
     * PUT request - Update existing data
     * @param {string} endpoint - API endpoint with ID (e.g., '/events/1')
     * @param {object} data - Updated data
     * @returns {Promise<any>} Updated resource
     */
    async put(endpoint, data) {
        try {
            const url = this.baseURL + endpoint;
            console.log('📡 PUT Request:', url, data);

            const response = await this.request(url, {
                method: 'PUT',
                body: JSON.stringify(data)
            });

            console.log('✅ PUT Response:', response);
            return response;

        } catch (error) {
            console.error('❌ PUT Error:', error);
            throw error;
        }
    },

    /**
     * PATCH request - Partially update data
     * @param {string} endpoint - API endpoint with ID
     * @param {object} data - Partial data to update
     * @returns {Promise<any>} Updated resource
     */
    async patch(endpoint, data) {
        try {
            const url = this.baseURL + endpoint;
            console.log('📡 PATCH Request:', url, data);

            const response = await this.request(url, {
                method: 'PATCH',
                body: JSON.stringify(data)
            });

            console.log('✅ PATCH Response:', response);
            return response;

        } catch (error) {
            console.error('❌ PATCH Error:', error);
            throw error;
        }
    },

    /**
     * DELETE request - Remove data
     * @param {string} endpoint - API endpoint with ID
     * @returns {Promise<any>} Deletion confirmation
     */
    async delete(endpoint) {
        try {
            const url = this.baseURL + endpoint;
            console.log('📡 DELETE Request:', url);

            const response = await this.request(url, {
                method: 'DELETE'
            });

            console.log('✅ DELETE Response:', response);
            return response;

        } catch (error) {
            console.error('❌ DELETE Error:', error);
            throw error;
        }
    },

    /**
     * Get a single event by ID
     * @param {number} id - Event ID
     * @returns {Promise<object>} Event object
     */
    async getEvent(id) {
        return await this.get(`${CONFIG.ENDPOINTS.EVENTS}/${id}`);
    },

    /**
     * Get all events with optional filtering
     * @param {object} filters - Filter parameters
     * @returns {Promise<array>} Array of events
     */
    async getEvents(filters = {}) {
        return await this.get(CONFIG.ENDPOINTS.EVENTS, filters);
    },

    /**
     * Create a new event
     * @param {object} eventData - Event data
     * @returns {Promise<object>} Created event
     */
    async createEvent(eventData) {
        return await this.post(CONFIG.ENDPOINTS.EVENTS, eventData);
    },

    /**
     * Update an existing event
     * @param {number} id - Event ID
     * @param {object} eventData - Updated event data
     * @returns {Promise<object>} Updated event
     */
    async updateEvent(id, eventData) {
        return await this.put(`${CONFIG.ENDPOINTS.EVENTS}/${id}`, eventData);
    },

    /**
     * Delete an event
     * @param {number} id - Event ID
     * @returns {Promise<any>} Deletion confirmation
     */
    async deleteEvent(id) {
        return await this.delete(`${CONFIG.ENDPOINTS.EVENTS}/${id}`);
    },

    /**
     * Get all users
     * @returns {Promise<array>} Array of users
     */
    async getUsers() {
        return await this.get(CONFIG.ENDPOINTS.USERS);
    },

    /**
     * Get a single user by ID
     * @param {number} id - User ID
     * @returns {Promise<object>} User object
     */
    async getUser(id) {
        return await this.get(`${CONFIG.ENDPOINTS.USERS}/${id}`);
    },

    /**
     * Register for an event
     * @param {number} userId - User ID
     * @param {number} eventId - Event ID
     * @returns {Promise<object>} Registration confirmation
     */
    async registerForEvent(userId, eventId) {
        try {
            // Get current event to check capacity
            const event = await this.getEvent(eventId);

            // Check if event is full
            if (event.currentAttendees >= event.maxCapacity) {
                throw new Error('This event has reached maximum capacity');
            }

            // Check if already registered
            const registrations = await this.get(CONFIG.ENDPOINTS.REGISTRATIONS, {
                userId: userId,
                eventId: eventId
            });

            if (registrations.length > 0) {
                throw new Error('You are already registered for this event');
            }

            // Create registration
            const registration = {
                userId: userId,
                eventId: eventId,
                registeredAt: new Date().toISOString(),
                status: 'confirmed'
            };

            const newRegistration = await this.post(CONFIG.ENDPOINTS.REGISTRATIONS, registration);

            // Update event attendee count
            const updatedEvent = await this.updateEvent(eventId, {
                ...event,
                currentAttendees: event.currentAttendees + 1,
                status: event.currentAttendees + 1 >= event.maxCapacity ? 'full' : 'active'
            });

            console.log('✅ Successfully registered for event');
            return { registration: newRegistration, event: updatedEvent };

        } catch (error) {
            console.error('❌ Registration error:', error);
            throw error;
        }
    },

    /**
     * Unregister from an event
     * @param {number} userId - User ID
     * @param {number} eventId - Event ID
     * @returns {Promise<any>} Unregistration confirmation
     */
    async unregisterFromEvent(userId, eventId) {
        try {
            // Find registration
            const registrations = await this.get(CONFIG.ENDPOINTS.REGISTRATIONS, {
                userId: userId,
                eventId: eventId
            });

            if (registrations.length === 0) {
                throw new Error('You are not registered for this event');
            }

            // Delete registration
            await this.delete(`${CONFIG.ENDPOINTS.REGISTRATIONS}/${registrations[0].id}`);

            // Get event and update attendee count
            const event = await this.getEvent(eventId);
            const updatedEvent = await this.updateEvent(eventId, {
                ...event,
                currentAttendees: Math.max(0, event.currentAttendees - 1),
                status: 'active' // Reopen event if it was full
            });

            console.log('✅ Successfully unregistered from event');
            return updatedEvent;

        } catch (error) {
            console.error('❌ Unregistration error:', error);
            throw error;
        }
    },

    /**
     * Check if user is registered for an event
     * @param {number} userId - User ID
     * @param {number} eventId - Event ID
     * @returns {Promise<boolean>} True if registered
     */
    async isRegistered(userId, eventId) {
        try {
            const registrations = await this.get(CONFIG.ENDPOINTS.REGISTRATIONS, {
                userId: userId,
                eventId: eventId
            });
            return registrations.length > 0;
        } catch (error) {
            console.error('❌ Check registration error:', error);
            return false;
        }
    },

    /**
     * Get user's registered events
     * @param {number} userId - User ID
     * @returns {Promise<array>} Array of events user is registered for
     */
    async getUserRegistrations(userId) {
        try {
            const registrations = await this.get(CONFIG.ENDPOINTS.REGISTRATIONS, {
                userId: userId
            });

            // Get full event details for each registration
            const events = await Promise.all(
                registrations.map(reg => this.getEvent(reg.eventId))
            );

            return events;

        } catch (error) {
            console.error('❌ Get user registrations error:', error);
            return [];
        }
    }
};

// Make API globally available
window.API = API;

console.log('✅ API module loaded successfully');
