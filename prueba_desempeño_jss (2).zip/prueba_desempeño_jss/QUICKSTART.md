# 🚀 Quick Start Guide

## Fastest Way to Run the Application

### Step 1: Install json-server (One-time setup)
```bash
npm install -g json-server
```

### Step 2: Start the Server
Open a terminal in the project folder and run:
```bash
json-server --watch db.json --port 3000
```

Keep this terminal open!

### Step 3: Open the Application

**Option A - Python (Recommended if you have Python)**
Open another terminal in the project folder:
```bash
python -m http.server 8000
```
Then open: http://localhost:8000

**Option B - VS Code Live Server**
1. Install "Live Server" extension in VS Code
2. Right-click on index.html
3. Click "Open with Live Server"

**Option C - Direct Browser (May have CORS issues)**
Simply open index.html in your browser

## Demo Credentials

**Admin Account:**
- Email: admin@events.com
- Password: Admin123!

**User Account:**
- Email: user@events.com
- Password: User123!

## Verify Everything is Working

1. You should see the login page
2. Login with admin credentials
3. You should see 3 pre-loaded events
4. Try creating a new event
5. Try registering for an event

## Troubleshooting

### "Cannot connect to server"
- Make sure json-server is running on port 3000
- Check terminal for any error messages
- Verify http://localhost:3000/events opens in browser

### CORS Errors
- Don't open index.html as a file (file://)
- Use a local server (Python, Live Server, etc.)

### Page is Blank
- Open DevTools (F12) and check Console tab
- Look for any error messages in red

## Project Structure

```
📁 event-management-system/
  📄 index.html          ← Main HTML file
  📄 styles.css          ← All styles
  📄 db.json            ← Database (DO NOT EDIT MANUALLY)
  📄 package.json        ← NPM configuration
  📁 js/                ← JavaScript modules
    📄 config.js         ← Configuration
    📄 utils.js          ← Utilities
    📄 auth.js           ← Authentication
    📄 api.js            ← API calls
    📄 router.js         ← Routing
    📄 components.js     ← UI components
    📄 events.js         ← Event pages
    📄 app.js            ← Entry point
```

## What You Can Do

### As Admin (admin@events.com):
✅ Create events
✅ Edit any event
✅ Delete any event
✅ Register for events
✅ View all events

### As Visitor (user@events.com):
✅ View all events
✅ Register for events
✅ Unregister from events
✅ View personal registrations
❌ Cannot create/edit/delete events

## Features Implemented

- ✅ User authentication with Local Storage
- ✅ Role-based access control (Admin/Visitor)
- ✅ Complete CRUD for events
- ✅ Event registration system
- ✅ Capacity management (prevents over-registration)
- ✅ Single Page Application (no page reloads)
- ✅ Client-side routing with protected routes
- ✅ Form validation
- ✅ Error handling with try/catch
- ✅ Toast notifications
- ✅ Responsive design
- ✅ Loading states
- ✅ 100% English code

## Need Help?

Check the full README.md for detailed documentation.

---
Good luck with your assessment! 🎉
