# 🏗️ System Architecture Documentation

## System Overview

The Event Management System is a Single Page Application (SPA) built with vanilla JavaScript, implementing modern web development patterns including modular architecture, client-side routing, and RESTful API integration.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        USER INTERFACE                            │
│                         (index.html)                             │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PRESENTATION LAYER                          │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │ components.js│  │   events.js  │  │  styles.css  │         │
│  │ (UI Render)  │  │ (Event Pages)│  │  (Styling)   │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      APPLICATION LAYER                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │   router.js  │  │   auth.js    │  │   utils.js   │         │
│  │  (Routing)   │  │(Auth Logic)  │  │  (Helpers)   │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      DATA ACCESS LAYER                           │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │    api.js    │  │  config.js   │  │ Local Storage│         │
│  │ (API Calls)  │  │(Constants)   │  │  (Session)   │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
└────────────────────────────┬────────────────────────────────────┘
                             │
                             ▼
┌─────────────────────────────────────────────────────────────────┐
│                      BACKEND (json-server)                       │
│                          db.json                                 │
│  ┌──────────┐  ┌──────────┐  ┌──────────────┐                 │
│  │  users   │  │  events  │  │registrations │                 │
│  └──────────┘  └──────────┘  └──────────────┘                 │
└─────────────────────────────────────────────────────────────────┘
```

## Module Dependencies

```
app.js (Entry Point)
  │
  ├── config.js (Loaded first)
  │
  ├── utils.js
  │
  ├── auth.js ───> utils.js
  │             └> config.js
  │
  ├── api.js ───> config.js
  │            └> utils.js
  │
  ├── router.js ─> utils.js
  │              └> auth.js
  │              └> components.js
  │
  ├── components.js ─> utils.js
  │                  └> auth.js
  │                  └> config.js
  │
  └── events.js ───> components.js
                   └> api.js
                   └> utils.js
```

## Data Flow

### 1. User Login Flow

```
User enters credentials
        │
        ▼
components.renderLogin()
        │
        ▼
Auth.login(email, password)
        │
        ├── Validate input
        │
        ├── API.get('/users')
        │       │
        │       ▼
        │   Fetch from json-server
        │       │
        │       ▼
        │   Find matching user
        │
        ├── Store in localStorage
        │
        └── Router.navigate('/')
                │
                ▼
        Render home page
```

### 2. Event Creation Flow (Admin)

```
Admin fills form
        │
        ▼
components.renderCreateEvent()
        │
        ▼
EventHandlers.createEvent()
        │
        ├── Collect form data
        │
        ├── Validate input
        │
        ├── Add metadata
        │       (createdBy, createdAt)
        │
        └── API.createEvent(data)
                │
                ▼
        POST /events to json-server
                │
                ▼
        Show success toast
                │
                ▼
        Router.navigate('/events')
```

### 3. Event Registration Flow

```
User clicks "Register"
        │
        ▼
EventHandlers.register(eventId)
        │
        ├── Get current user
        │
        └── API.registerForEvent(userId, eventId)
                │
                ├── Check event capacity
                │       │
                │       ▼
                │   If full → throw error
                │
                ├── Check if already registered
                │       │
                │       ▼
                │   If yes → throw error
                │
                ├── POST /registrations
                │
                ├── Update event.currentAttendees
                │       │
                │       └── PUT /events/:id
                │
                └── Return success
                        │
                        ▼
                Show success toast
                        │
                        ▼
                Reload page to show updated status
```

## Routing System

### Route Protection Logic

```
User navigates to route
        │
        ▼
Router.handleRoute(path)
        │
        ├── Match route pattern
        │       │
        │       ├── Exact match: /login
        │       └── Dynamic: /events/:id
        │
        ├── Check requiresAuth
        │       │
        │       └── If true and not authenticated
        │               └── Redirect to /login
        │
        ├── Check requiredRole
        │       │
        │       └── If set and user lacks role
        │               └── Redirect to /
        │
        └── Call route handler
                │
                └── Render page
```

### Route Definitions

| Path | Handler | Auth Required | Admin Only |
|------|---------|---------------|------------|
| /login | renderLogin | No | No |
| /register | renderRegister | No | No |
| / | renderHome | Yes | No |
| /events | renderEventsList | Yes | No |
| /events/:id | renderEventDetail | Yes | No |
| /events/create | renderCreateEvent | Yes | Yes |
| /events/edit/:id | renderEditEvent | Yes | Yes |
| /my-events | renderMyEvents | Yes | No |

## State Management

### Local Storage Structure

```javascript
{
  "eventapp_user": {
    "id": 1,
    "email": "admin@events.com",
    "name": "Administrator",
    "role": "admin",
    "createdAt": "2024-01-01T00:00:00.000Z"
  }
}
```

### Database Schema (db.json)

#### Users Collection
```javascript
{
  "id": number,
  "email": string,
  "password": string,
  "name": string,
  "role": "admin" | "visitor",
  "createdAt": string (ISO date)
}
```

#### Events Collection
```javascript
{
  "id": number,
  "title": string,
  "description": string,
  "date": string (YYYY-MM-DD),
  "time": string (HH:mm),
  "location": string,
  "maxCapacity": number,
  "currentAttendees": number,
  "category": string,
  "status": "active" | "full" | "cancelled",
  "createdBy": number (user id),
  "createdAt": string (ISO date)
}
```

#### Registrations Collection
```javascript
{
  "id": number,
  "userId": number,
  "eventId": number,
  "registeredAt": string (ISO date),
  "status": "confirmed"
}
```

## API Endpoints & Operations

### GET Operations
- `GET /users` - Fetch all users (for authentication)
- `GET /events` - Fetch all events (for listing)
- `GET /events/:id` - Fetch single event (for details)
- `GET /registrations?userId=:id` - Get user's registrations
- `GET /registrations?eventId=:id` - Get event's registrations

### POST Operations
- `POST /users` - Create new user (registration)
- `POST /events` - Create new event (admin only)
- `POST /registrations` - Register for event

### PUT Operations
- `PUT /events/:id` - Update event (admin only)
- Used for capacity updates when registering

### DELETE Operations
- `DELETE /events/:id` - Delete event (admin only)
- `DELETE /registrations/:id` - Unregister from event

## Error Handling Strategy

### Levels of Error Handling

1. **Input Validation** (Client-side)
   - Prevents invalid data entry
   - Immediate user feedback
   - No API calls made

2. **API Error Handling** (Network level)
   - try...catch on all async operations
   - Specific error messages
   - Graceful degradation

3. **Application Error Handling** (App level)
   - Global error listeners
   - Fallback UI for critical errors
   - Console logging for debugging

### Example Error Flow

```
User submits form
        │
        ▼
Validate input
        │
        ├── Invalid → Show error, stop
        │
        └── Valid → Continue
                │
                ▼
        try {
            await API.createEvent()
        }       │
                ├── Success → Show toast, navigate
                │
                └── catch (error)
                        │
                        ├── Network error?
                        │   └── "Cannot connect to server"
                        │
                        ├── Validation error?
                        │   └── Show specific message
                        │
                        └── Unknown error
                            └── "An unexpected error occurred"
```

## Security Considerations

### Implemented
- ✅ Input sanitization (XSS prevention)
- ✅ Email validation
- ✅ Password length requirements
- ✅ Route protection (authentication)
- ✅ Role-based access control
- ✅ Client-side validation

### Production Recommendations
- ⚠️ Hash passwords (currently plain text)
- ⚠️ Implement JWT tokens
- ⚠️ Add HTTPS in production
- ⚠️ Rate limiting on API
- ⚠️ CSRF protection
- ⚠️ Server-side validation

## Performance Optimizations

1. **Modular Loading**
   - Separate JavaScript files
   - Only load what's needed

2. **Efficient DOM Manipulation**
   - Batch updates
   - Use documentFragment where appropriate
   - Minimize reflows

3. **Caching**
   - Local Storage for session
   - Reduce redundant API calls

4. **Debouncing**
   - Utils.debounce() for frequent operations

## Browser Compatibility

### Tested Browsers
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+

### Required Features
- ES6+ JavaScript
- Fetch API
- Local Storage
- CSS Grid & Flexbox
- Arrow functions
- async/await

## Development Workflow

1. **Start json-server**
   ```bash
   json-server --watch db.json --port 3000
   ```

2. **Start local server**
   ```bash
   python -m http.server 8000
   ```

3. **Open browser**
   ```
   http://localhost:8000
   ```

4. **Development**
   - Edit files
   - Refresh browser
   - Check console for errors

5. **Testing**
   - Test all CRUD operations
   - Test authentication flows
   - Test edge cases
   - Test responsive design

## Deployment Checklist

- [ ] Change API_URL in config.js to production URL
- [ ] Implement proper backend API
- [ ] Add password hashing
- [ ] Add JWT authentication
- [ ] Enable HTTPS
- [ ] Minify JavaScript
- [ ] Optimize images
- [ ] Add service worker for offline support
- [ ] Add analytics
- [ ] Add error reporting service

---

This architecture provides a solid foundation for a scalable, maintainable event management system while demonstrating mastery of fundamental web development concepts.
