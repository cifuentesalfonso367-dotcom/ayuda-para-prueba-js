/**
 * ============================================
 * UTILITY FUNCTIONS
 * ============================================
 * 
 * This file contains reusable utility functions
 * used throughout the application.
 */

const Utils = {
    /**
     * Display a toast notification to the user
     * @param {string} message - The message to display
     * @param {string} type - Type of toast: 'success', 'error', 'warning', 'info'
     * @param {number} duration - How long to display the toast (ms)
     */
    showToast(message, type = 'success', duration = CONFIG.UI.TOAST_DURATION) {
        const container = document.getElementById('toastContainer');
        
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        // Icon based on type
        const icons = {
            success: '✓',
            error: '✕',
            warning: '⚠',
            info: 'ℹ'
        };
        
        // Build toast HTML
        toast.innerHTML = `
            <div class="toast-icon">${icons[type] || icons.info}</div>
            <div class="toast-content">
                <div class="toast-title">${type.charAt(0).toUpperCase() + type.slice(1)}</div>
                <div class="toast-message">${message}</div>
            </div>
        `;
        
        // Add to container
        container.appendChild(toast);
        
        // Remove after duration
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(400px)';
            setTimeout(() => toast.remove(), 300);
        }, duration);
        
        console.log(`[${type.toUpperCase()}] ${message}`);
    },

    /**
     * Format a date string to a readable format
     * @param {string} dateString - ISO date string
     * @returns {string} Formatted date
     */
    formatDate(dateString) {
        const date = new Date(dateString);
        const options = { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
        };
        return date.toLocaleDateString('en-US', options);
    },

    /**
     * Format time string to 12-hour format
     * @param {string} timeString - Time in HH:mm format
     * @returns {string} Formatted time
     */
    formatTime(timeString) {
        const [hours, minutes] = timeString.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour % 12 || 12;
        return `${displayHour}:${minutes} ${ampm}`;
    },

    /**
     * Validate email format
     * @param {string} email - Email to validate
     * @returns {boolean} True if valid
     */
    validateEmail(email) {
        return CONFIG.VALIDATION.EMAIL_REGEX.test(email);
    },

    /**
     * Validate password strength
     * @param {string} password - Password to validate
     * @returns {object} Validation result with isValid and message
     */
    validatePassword(password) {
        if (!password || password.length < CONFIG.VALIDATION.MIN_PASSWORD_LENGTH) {
            return {
                isValid: false,
                message: `Password must be at least ${CONFIG.VALIDATION.MIN_PASSWORD_LENGTH} characters long`
            };
        }
        return { isValid: true, message: 'Password is valid' };
    },

    /**
     * Sanitize HTML to prevent XSS attacks
     * @param {string} html - HTML string to sanitize
     * @returns {string} Sanitized HTML
     */
    sanitizeHTML(html) {
        const div = document.createElement('div');
        div.textContent = html;
        return div.innerHTML;
    },

    /**
     * Show loading indicator
     */
    showLoading() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.display = 'flex';
        }
    },

    /**
     * Hide loading indicator
     */
    hideLoading() {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.display = 'none';
        }
    },

    /**
     * Calculate percentage for capacity
     * @param {number} current - Current attendees
     * @param {number} max - Max capacity
     * @returns {number} Percentage
     */
    calculateCapacityPercentage(current, max) {
        return Math.round((current / max) * 100);
    },

    /**
     * Get capacity status (for styling)
     * @param {number} percentage - Capacity percentage
     * @returns {string} Status: 'normal', 'warning', or 'full'
     */
    getCapacityStatus(percentage) {
        if (percentage >= 100) return 'full';
        if (percentage >= 80) return 'warning';
        return 'normal';
    },

    /**
     * Debounce function to limit how often a function can run
     * @param {Function} func - Function to debounce
     * @param {number} wait - Wait time in ms
     * @returns {Function} Debounced function
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Check if user is authenticated
     * @returns {boolean} True if authenticated
     */
    isAuthenticated() {
        return localStorage.getItem(CONFIG.STORAGE_KEYS.USER) !== null;
    },

    /**
     * Get current user from local storage
     * @returns {object|null} User object or null
     */
    getCurrentUser() {
        const userJSON = localStorage.getItem(CONFIG.STORAGE_KEYS.USER);
        return userJSON ? JSON.parse(userJSON) : null;
    },

    /**
     * Check if current user is admin
     * @returns {boolean} True if admin
     */
    isAdmin() {
        const user = this.getCurrentUser();
        return user && user.role === CONFIG.ROLES.ADMIN;
    },

    /**
     * Generate a unique ID
     * @returns {number} Unique timestamp-based ID
     */
    generateId() {
        return Date.now();
    },

    /**
     * Deep clone an object
     * @param {object} obj - Object to clone
     * @returns {object} Cloned object
     */
    deepClone(obj) {
        return JSON.parse(JSON.stringify(obj));
    },

    /**
     * Format error message from API or validation
     * @param {Error|string} error - Error object or message
     * @returns {string} Formatted error message
     */
    formatError(error) {
        if (typeof error === 'string') return error;
        if (error.message) return error.message;
        return 'An unexpected error occurred';
    },

    /**
     * Scroll to top of page smoothly
     */
    scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    },

    /**
     * Get initials from name for avatar
     * @param {string} name - Full name
     * @returns {string} Initials (max 2 letters)
     */
    getInitials(name) {
        if (!name) return '?';
        const parts = name.trim().split(' ');
        if (parts.length >= 2) {
            return (parts[0][0] + parts[1][0]).toUpperCase();
        }
        return name.substring(0, 2).toUpperCase();
    },

    /**
     * Check if a date is in the past
     * @param {string} dateString - Date to check
     * @returns {boolean} True if date is in the past
     */
    isPastDate(dateString) {
        const date = new Date(dateString);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        return date < today;
    },

    /**
     * Format number with commas
     * @param {number} number - Number to format
     * @returns {string} Formatted number
     */
    formatNumber(number) {
        return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
};

// Make Utils globally available
window.Utils = Utils;

console.log('✅ Utilities loaded successfully');
