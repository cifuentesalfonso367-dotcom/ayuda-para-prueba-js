/**
 * ============================================
 * CONFIGURATION FILE
 * ============================================
 * 
 * This file contains all the configuration constants
 * used throughout the application.
 * 
 * IMPORTANT: Make sure json-server is running on port 3000
 * Command: json-server --watch db.json --port 3000
 */

const CONFIG = {
    // API Base URL - Change this if your server runs on a different port
    API_URL: 'http://localhost:3000',
    
    // API Endpoints for different resources
    ENDPOINTS: {
        USERS: '/users',
        EVENTS: '/events',
        REGISTRATIONS: '/registrations'
    },
    
    // Local Storage keys for data persistence
    STORAGE_KEYS: {
        USER: 'eventapp_user',           // Stores authenticated user data
        TOKEN: 'eventapp_token',         // Stores authentication token (if needed)
        SESSION: 'eventapp_session'      // Stores session information
    },
    
    // User roles definition
    ROLES: {
        ADMIN: 'admin',       // Can create, edit, and delete events
        VISITOR: 'visitor'    // Can only view and register for events
    },
    
    // Event status options
    EVENT_STATUS: {
        ACTIVE: 'active',     // Event is open for registration
        FULL: 'full',         // Event has reached max capacity
        CANCELLED: 'cancelled', // Event has been cancelled
        COMPLETED: 'completed' // Event has already happened
    },
    
    // Event categories
    EVENT_CATEGORIES: [
        'Technology',
        'Business',
        'Marketing',
        'Education',
        'Health',
        'Sports',
        'Arts',
        'Music',
        'Other'
    ],
    
    // Application routes
    ROUTES: {
        LOGIN: '/login',
        REGISTER: '/register',
        HOME: '/',
        EVENTS: '/events',
        EVENT_DETAIL: '/events/:id',
        CREATE_EVENT: '/events/create',
        EDIT_EVENT: '/events/edit/:id',
        MY_EVENTS: '/my-events',
        PROFILE: '/profile'
    },
    
    // Validation rules
    VALIDATION: {
        MIN_PASSWORD_LENGTH: 6,
        MIN_NAME_LENGTH: 3,
        EMAIL_REGEX: /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    },
    
    // UI Configuration
    UI: {
        TOAST_DURATION: 3000,        // How long toast messages are displayed (ms)
        LOADING_DELAY: 300,          // Delay before showing loading indicator (ms)
        ANIMATION_DURATION: 300      // Duration of animations (ms)
    }
};

// Make CONFIG globally available
window.CONFIG = CONFIG;

console.log('✅ Configuration loaded successfully');
