/**
 * ============================================
 * ROUTER MODULE - Single Page Application
 * ============================================
 * 
 * This module handles client-side routing without page reloads.
 * It manages navigation, protected routes, and dynamic route parameters.
 */

const Router = {
    /**
     * Current route information
     */
    currentRoute: null,
    
    /**
     * Route definitions with their handlers
     */
    routes: {},

    /**
     * Register a new route
     * @param {string} path - Route path (e.g., '/events/:id')
     * @param {Function} handler - Function to call when route matches
     * @param {boolean} requiresAuth - Whether route requires authentication
     * @param {string} requiredRole - Required user role (optional)
     */
    addRoute(path, handler, requiresAuth = false, requiredRole = null) {
        this.routes[path] = {
            handler,
            requiresAuth,
            requiredRole
        };
    },

    /**
     * Initialize the router
     */
    init() {
        // Define all application routes
        this.defineRoutes();

        // Handle browser back/forward buttons
        window.addEventListener('popstate', () => {
            this.handleRoute(window.location.pathname);
        });

        // Handle initial page load
        this.handleRoute(window.location.pathname);

        // Intercept all link clicks to handle routing
        document.addEventListener('click', (e) => {
            // Check if clicked element is a link
            const link = e.target.closest('a[href]');
            if (!link) return;

            const href = link.getAttribute('href');
            
            // Only handle internal links (starting with /)
            if (href && href.startsWith('/')) {
                e.preventDefault();
                this.navigate(href);
            }
        });

        console.log('✅ Router initialized with routes:', Object.keys(this.routes));
    },

    /**
     * Define all application routes
     */
    defineRoutes() {
        // Public routes
        this.addRoute('/login', Components.renderLogin, false);
        this.addRoute('/register', Components.renderRegister, false);
        
        // Protected routes (require authentication)
        this.addRoute('/', Components.renderHome, true);
        this.addRoute('/events', Components.renderEventsList, true);
        this.addRoute('/events/:id', Components.renderEventDetail, true);
        this.addRoute('/my-events', Components.renderMyEvents, true);
        
        // Admin only routes
        this.addRoute('/events/create', Components.renderCreateEvent, true, CONFIG.ROLES.ADMIN);
        this.addRoute('/events/edit/:id', Components.renderEditEvent, true, CONFIG.ROLES.ADMIN);
    },

    /**
     * Navigate to a new route
     * @param {string} path - Path to navigate to
     */
    navigate(path) {
        // Update browser URL without reload
        window.history.pushState({}, '', path);
        
        // Handle the route
        this.handleRoute(path);
        
        // Scroll to top of page
        Utils.scrollToTop();
    },

    /**
     * Handle a route change
     * @param {string} path - Current path
     */
    async handleRoute(path) {
        console.log('🔄 Navigating to:', path);

        // Find matching route
        const { route, params } = this.matchRoute(path);

        if (!route) {
            console.warn('⚠ Route not found:', path);
            this.navigate('/'); // Redirect to home
            return;
        }

        // Check authentication requirements
        if (route.requiresAuth && !Utils.isAuthenticated()) {
            console.warn('⚠ Authentication required');
            Utils.showToast('Please login to continue', 'warning');
            this.navigate('/login');
            return;
        }

        // Check role requirements
        if (route.requiredRole) {
            const user = Utils.getCurrentUser();
            if (!user || user.role !== route.requiredRole) {
                console.warn('⚠ Insufficient permissions');
                Utils.showToast('You do not have permission to access this page', 'error');
                this.navigate('/');
                return;
            }
        }

        // Store current route
        this.currentRoute = { path, params };

        try {
            // Show loading
            Utils.showLoading();

            // Call route handler with parameters
            await route.handler(params);

            // Hide loading
            Utils.hideLoading();

        } catch (error) {
            console.error('❌ Route handler error:', error);
            Utils.hideLoading();
            Utils.showToast('Error loading page', 'error');
        }
    },

    /**
     * Match a path to a route and extract parameters
     * @param {string} path - Path to match
     * @returns {object} Matched route and extracted parameters
     */
    matchRoute(path) {
        // Try to find exact match first
        if (this.routes[path]) {
            return { route: this.routes[path], params: {} };
        }

        // Try to match dynamic routes
        for (const routePath in this.routes) {
            const params = this.extractParams(routePath, path);
            if (params !== null) {
                return { route: this.routes[routePath], params };
            }
        }

        return { route: null, params: {} };
    },

    /**
     * Extract parameters from a dynamic route
     * @param {string} routePath - Route pattern (e.g., '/events/:id')
     * @param {string} actualPath - Actual path (e.g., '/events/123')
     * @returns {object|null} Extracted parameters or null if no match
     */
    extractParams(routePath, actualPath) {
        const routeParts = routePath.split('/');
        const actualParts = actualPath.split('/');

        // Paths must have same number of parts
        if (routeParts.length !== actualParts.length) {
            return null;
        }

        const params = {};

        for (let i = 0; i < routeParts.length; i++) {
            const routePart = routeParts[i];
            const actualPart = actualParts[i];

            if (routePart.startsWith(':')) {
                // This is a parameter
                const paramName = routePart.slice(1);
                params[paramName] = actualPart;
            } else if (routePart !== actualPart) {
                // Parts don't match
                return null;
            }
        }

        return params;
    },

    /**
     * Get query parameters from URL
     * @returns {object} Query parameters as key-value pairs
     */
    getQueryParams() {
        const params = {};
        const searchParams = new URLSearchParams(window.location.search);
        
        for (const [key, value] of searchParams) {
            params[key] = value;
        }
        
        return params;
    },

    /**
     * Go back to previous page
     */
    back() {
        window.history.back();
    },

    /**
     * Reload current route
     */
    reload() {
        this.handleRoute(window.location.pathname);
    }
};

// Make Router globally available
window.Router = Router;

console.log('✅ Router module loaded successfully');
