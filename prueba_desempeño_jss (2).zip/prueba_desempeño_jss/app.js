/**
 * ============================================
 * MAIN APPLICATION FILE
 * ============================================
 * 
 * This is the entry point of the application.
 * It initializes all modules and starts the app.
 * 
 * IMPORTANT: Make sure json-server is running before starting:
 * Command: json-server --watch db.json --port 3000
 */

/**
 * Application initialization
 */
const App = {
    /**
     * Initialize the application
     */
    async init() {
        try {
            console.log('🚀 Event Management System - Starting...');
            console.log('='.repeat(50));

            // Show loading screen
            Utils.showLoading();

            // Initialize authentication state
            Auth.init();

            // Check if user is authenticated
            const isAuthenticated = Utils.isAuthenticated();
            console.log(`Authentication status: ${isAuthenticated ? '✅ Authenticated' : '❌ Not authenticated'}`);

            if (isAuthenticated) {
                const user = Utils.getCurrentUser();
                console.log(`Current user: ${user.email} (${user.role})`);
            }

            // Test API connection
            await this.testAPIConnection();

            // Initialize router (this will load the first page)
            Router.init();

            // Hide loading screen
            Utils.hideLoading();

            console.log('='.repeat(50));
            console.log('✅ Event Management System - Ready!');
            console.log('='.repeat(50));

            // Show welcome message
            if (isAuthenticated) {
                const user = Utils.getCurrentUser();
                console.log(`Welcome back, ${user.name}!`);
            } else {
                console.log('Please login to continue');
            }

        } catch (error) {
            console.error('❌ Application initialization failed:', error);
            Utils.hideLoading();
            Utils.showToast('Failed to initialize application. Please check if json-server is running.', 'error');
            
            // Show error page
            this.showErrorPage(error);
        }
    },

    /**
     * Test API connection
     */
    async testAPIConnection() {
        try {
            console.log('Testing API connection...');
            
            // Try to fetch users (lightest endpoint)
            const users = await API.get(CONFIG.ENDPOINTS.USERS);
            
            console.log(`✅ API Connection successful (${users.length} users found)`);
            return true;

        } catch (error) {
            console.error('❌ API Connection failed:', error);
            throw new Error('Cannot connect to json-server. Please make sure it is running on port 3000.');
        }
    },

    /**
     * Show error page when app fails to initialize
     * @param {Error} error - Error object
     */
    showErrorPage(error) {
        const app = document.getElementById('app');
        
        app.innerHTML = `
            <div style="
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100vh;
                text-align: center;
                padding: 2rem;
                color: white;
            ">
                <div style="font-size: 5rem; margin-bottom: 1rem;">⚠️</div>
                <h1 style="font-size: 2rem; margin-bottom: 1rem;">
                    Application Error
                </h1>
                <p style="
                    max-width: 600px;
                    margin-bottom: 2rem;
                    line-height: 1.6;
                    opacity: 0.9;
                ">
                    ${Utils.formatError(error)}
                </p>
                <div style="
                    background: rgba(255, 255, 255, 0.1);
                    padding: 1.5rem;
                    border-radius: 0.5rem;
                    max-width: 600px;
                    text-align: left;
                ">
                    <h3 style="margin-bottom: 1rem;">🔧 Troubleshooting Steps:</h3>
                    <ol style="line-height: 2; padding-left: 1.5rem;">
                        <li>Make sure <strong>json-server</strong> is installed:
                            <br><code style="
                                background: rgba(0, 0, 0, 0.3);
                                padding: 0.25rem 0.5rem;
                                border-radius: 0.25rem;
                                display: inline-block;
                                margin-top: 0.5rem;
                            ">npm install -g json-server</code>
                        </li>
                        <li>Start json-server in the project directory:
                            <br><code style="
                                background: rgba(0, 0, 0, 0.3);
                                padding: 0.25rem 0.5rem;
                                border-radius: 0.25rem;
                                display: inline-block;
                                margin-top: 0.5rem;
                            ">json-server --watch db.json --port 3000</code>
                        </li>
                        <li>Verify json-server is running at:
                            <br><code style="
                                background: rgba(0, 0, 0, 0.3);
                                padding: 0.25rem 0.5rem;
                                border-radius: 0.25rem;
                                display: inline-block;
                                margin-top: 0.5rem;
                            ">http://localhost:3000</code>
                        </li>
                        <li>Check the browser console for detailed error messages</li>
                        <li>Refresh the page after json-server is running</li>
                    </ol>
                </div>
                <button 
                    onclick="location.reload()" 
                    style="
                        margin-top: 2rem;
                        padding: 1rem 2rem;
                        background: white;
                        color: var(--primary-color);
                        border: none;
                        border-radius: 0.5rem;
                        font-size: 1rem;
                        font-weight: 600;
                        cursor: pointer;
                    "
                >
                    🔄 Retry
                </button>
            </div>
        `;
    }
};

/**
 * Start the application when DOM is fully loaded
 */
document.addEventListener('DOMContentLoaded', () => {
    App.init();
});

/**
 * Handle errors globally
 */
window.addEventListener('error', (event) => {
    console.error('Global error caught:', event.error);
});

/**
 * Handle unhandled promise rejections
 */
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
});

console.log('✅ Application file loaded successfully');
