/**
 * ============================================
 * COMPONENTS MODULE
 * ============================================
 * 
 * This module contains all UI components and page renderers.
 * Each component is responsible for rendering a specific view.
 */

const Components = {
    /**
     * Get the main app container
     * @returns {HTMLElement} App container
     */
    getAppContainer() {
        return document.getElementById('app');
    },

    /**
     * Render navigation bar
     * @returns {string} Navigation HTML
     */
    renderNavbar() {
        const user = Utils.getCurrentUser();
        
        if (!user) return ''; // No navbar for non-authenticated users

        const isAdmin = user.role === CONFIG.ROLES.ADMIN;

        return `
            <nav class="navbar">
                <div class="navbar-container">
                    <a href="/" class="navbar-brand">
                        🎉 Event Manager
                    </a>
                    <ul class="navbar-menu">
                        <li><a href="/" class="navbar-link">Home</a></li>
                        <li><a href="/events" class="navbar-link">Events</a></li>
                        <li><a href="/my-events" class="navbar-link">My Events</a></li>
                        ${isAdmin ? '<li><a href="/events/create" class="navbar-link">Create Event</a></li>' : ''}
                        <li class="user-info">
                            <div class="user-avatar">${Utils.getInitials(user.name)}</div>
                            <div>
                                <div class="user-name">${user.name}</div>
                                <span class="user-role">${user.role}</span>
                            </div>
                        </li>
                        <li><button class="btn btn-secondary btn-sm" onclick="Auth.logout()">Logout</button></li>
                    </ul>
                </div>
            </nav>
        `;
    },

    /**
     * Render login page
     */
    async renderLogin() {
        const app = this.getAppContainer();
        
        app.innerHTML = `
            <div class="auth-container">
                <div class="auth-card">
                    <div class="auth-header">
                        <div class="auth-logo">🎉</div>
                        <h1 class="auth-title">Welcome Back</h1>
                        <p class="auth-subtitle">Login to manage your events</p>
                    </div>

                    <form id="loginForm">
                        <div class="form-group">
                            <label for="email" class="form-label required">Email</label>
                            <input 
                                type="email" 
                                id="email" 
                                class="form-input" 
                                placeholder="Enter your email"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="password" class="form-label required">Password</label>
                            <input 
                                type="password" 
                                id="password" 
                                class="form-input" 
                                placeholder="Enter your password"
                                required
                            >
                        </div>

                        <button type="submit" class="btn btn-primary btn-block btn-lg">
                            Login
                        </button>
                    </form>

                    <div class="text-center mt-3">
                        <p class="form-hint">
                            Don't have an account? 
                            <a href="/register" style="color: var(--primary-color); font-weight: 600;">
                                Register here
                            </a>
                        </p>
                    </div>

                    <div class="mt-4" style="padding: 1rem; background: var(--bg-color); border-radius: var(--radius-md); font-size: 0.875rem;">
                        <strong>Demo Credentials:</strong><br>
                        <strong>Admin:</strong> admin@events.com / Admin123!<br>
                        <strong>User:</strong> user@events.com / User123!
                    </div>
                </div>
            </div>
        `;

        // Handle form submission
        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;

            try {
                await Auth.login(email, password);
                Router.navigate('/');
            } catch (error) {
                // Error is already handled in Auth.login
            }
        });
    },

    /**
     * Render registration page
     */
    async renderRegister() {
        const app = this.getAppContainer();
        
        app.innerHTML = `
            <div class="auth-container">
                <div class="auth-card">
                    <div class="auth-header">
                        <div class="auth-logo">📝</div>
                        <h1 class="auth-title">Create Account</h1>
                        <p class="auth-subtitle">Join us to manage amazing events</p>
                    </div>

                    <form id="registerForm">
                        <div class="form-group">
                            <label for="name" class="form-label required">Full Name</label>
                            <input 
                                type="text" 
                                id="name" 
                                class="form-input" 
                                placeholder="Enter your full name"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="email" class="form-label required">Email</label>
                            <input 
                                type="email" 
                                id="email" 
                                class="form-input" 
                                placeholder="Enter your email"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="password" class="form-label required">Password</label>
                            <input 
                                type="password" 
                                id="password" 
                                class="form-input" 
                                placeholder="Create a password"
                                required
                            >
                            <span class="form-hint">
                                Password must be at least ${CONFIG.VALIDATION.MIN_PASSWORD_LENGTH} characters
                            </span>
                        </div>

                        <div class="form-group">
                            <label for="role" class="form-label required">Role</label>
                            <select id="role" class="form-select" required>
                                <option value="${CONFIG.ROLES.VISITOR}">Visitor</option>
                                <option value="${CONFIG.ROLES.ADMIN}">Admin</option>
                            </select>
                            <span class="form-hint">
                                Admins can create and manage events
                            </span>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block btn-lg">
                            Create Account
                        </button>
                    </form>

                    <div class="text-center mt-3">
                        <p class="form-hint">
                            Already have an account? 
                            <a href="/login" style="color: var(--primary-color); font-weight: 600;">
                                Login here
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        `;

        // Handle form submission
        document.getElementById('registerForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const userData = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                password: document.getElementById('password').value,
                role: document.getElementById('role').value
            };

            try {
                await Auth.register(userData);
                Router.navigate('/login');
            } catch (error) {
                // Error is already handled in Auth.register
            }
        });
    },

    /**
     * Render home page
     */
    async renderHome() {
        const app = this.getAppContainer();
        const user = Utils.getCurrentUser();
        
        try {
            // Fetch statistics
            const events = await API.getEvents();
            const totalEvents = events.length;
            const activeEvents = events.filter(e => e.status === 'active').length;
            const fullEvents = events.filter(e => e.status === 'full').length;
            
            let myRegistrations = [];
            if (user) {
                myRegistrations = await API.getUserRegistrations(user.id);
            }

            app.innerHTML = `
                ${this.renderNavbar()}
                <div class="container">
                    <div class="page-container">
                        <div class="page-header">
                            <div>
                                <h1 class="page-title">Welcome, ${user.name}! 👋</h1>
                                <p style="color: var(--text-secondary); margin-top: 0.5rem;">
                                    Manage and discover amazing events
                                </p>
                            </div>
                            ${user.role === CONFIG.ROLES.ADMIN ? 
                                '<a href="/events/create" class="btn btn-primary">+ Create Event</a>' 
                                : ''
                            }
                        </div>

                        <!-- Statistics Cards -->
                        <div class="grid grid-cols-3 mb-4">
                            <div class="card">
                                <div class="card-title">📊 Total Events</div>
                                <div style="font-size: 2.5rem; font-weight: 700; color: var(--primary-color);">
                                    ${totalEvents}
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-title">✅ Active Events</div>
                                <div style="font-size: 2.5rem; font-weight: 700; color: var(--success-color);">
                                    ${activeEvents}
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-title">🎫 My Registrations</div>
                                <div style="font-size: 2.5rem; font-weight: 700; color: var(--info-color);">
                                    ${myRegistrations.length}
                                </div>
                            </div>
                        </div>

                        <!-- Quick Actions -->
                        <div class="card mb-4">
                            <h2 style="margin-bottom: 1rem;">Quick Actions</h2>
                            <div class="flex gap-2">
                                <a href="/events" class="btn btn-primary">Browse All Events</a>
                                <a href="/my-events" class="btn btn-secondary">My Registered Events</a>
                                ${user.role === CONFIG.ROLES.ADMIN ? 
                                    '<a href="/events/create" class="btn btn-success">Create New Event</a>' 
                                    : ''
                                }
                            </div>
                        </div>

                        <!-- Upcoming Events -->
                        <h2 style="margin-bottom: 1rem;">Upcoming Events</h2>
                        <div class="grid grid-cols-2">
                            ${events.slice(0, 4).map(event => this.renderEventCard(event)).join('')}
                        </div>

                        ${events.length === 0 ? `
                            <div class="empty-state">
                                <div class="empty-state-icon">📅</div>
                                <h3 class="empty-state-title">No Events Yet</h3>
                                <p class="empty-state-message">
                                    Be the first to create an event!
                                </p>
                                ${user.role === CONFIG.ROLES.ADMIN ? 
                                    '<a href="/events/create" class="btn btn-primary">Create First Event</a>' 
                                    : ''
                                }
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;

        } catch (error) {
            console.error('Error rendering home:', error);
            Utils.showToast('Error loading home page', 'error');
        }
    },

    /**
     * Render event card component
     * @param {object} event - Event object
     * @returns {string} Event card HTML
     */
    renderEventCard(event) {
        const capacityPercent = Utils.calculateCapacityPercentage(
            event.currentAttendees, 
            event.maxCapacity
        );
        const capacityStatus = Utils.getCapacityStatus(capacityPercent);
        
        const statusBadge = event.status === 'active' 
            ? '<span class="badge badge-success">Active</span>'
            : '<span class="badge badge-danger">Full</span>';

        return `
            <div class="card event-card">
                <div class="event-status">${statusBadge}</div>
                
                <div class="card-header">
                    <div>
                        <h3 class="card-title">${Utils.sanitizeHTML(event.title)}</h3>
                        <span class="badge badge-primary">${event.category}</span>
                    </div>
                </div>

                <p class="card-body">
                    ${Utils.sanitizeHTML(event.description)}
                </p>

                <div class="event-meta">
                    <div class="event-meta-item">
                        📅 ${Utils.formatDate(event.date)}
                    </div>
                    <div class="event-meta-item">
                        🕐 ${Utils.formatTime(event.time)}
                    </div>
                    <div class="event-meta-item">
                        📍 ${Utils.sanitizeHTML(event.location)}
                    </div>
                </div>

                <div class="event-capacity">
                    <div class="capacity-bar">
                        <div class="capacity-fill ${capacityStatus}" 
                             style="width: ${capacityPercent}%"></div>
                    </div>
                    <span class="capacity-text">
                        ${event.currentAttendees} / ${event.maxCapacity}
                    </span>
                </div>

                <div class="card-footer">
                    <a href="/events/${event.id}" class="btn btn-primary btn-sm">
                        View Details
                    </a>
                </div>
            </div>
        `;
    }
};

// Make Components globally available
window.Components = Components;

console.log('✅ Components module loaded (Part 1)');
