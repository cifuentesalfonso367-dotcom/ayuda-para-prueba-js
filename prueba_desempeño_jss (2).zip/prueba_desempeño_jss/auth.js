/**
 * ============================================
 * AUTHENTICATION MODULE
 * ============================================
 * 
 * This module handles all authentication-related operations:
 * - User login
 * - User registration
 * - Session management
 * - Logout
 * - Role checking
 */

const Auth = {
    /**
     * Login a user with email and password
     * @param {string} email - User email
     * @param {string} password - User password
     * @returns {Promise<object>} User object if successful
     * @throws {Error} If credentials are invalid
     */
    async login(email, password) {
        try {
            // Validate input
            if (!email || !password) {
                throw new Error('Email and password are required');
            }

            if (!Utils.validateEmail(email)) {
                throw new Error('Invalid email format');
            }

            console.log('Attempting login for:', email);

            // Fetch all users from API
            const users = await API.get(CONFIG.ENDPOINTS.USERS);

            // Find user with matching credentials
            const user = users.find(u => 
                u.email.toLowerCase() === email.toLowerCase() && 
                u.password === password
            );

            // Check if user exists
            if (!user) {
                throw new Error('Invalid email or password');
            }

            // Store user in session (without password for security)
            const userSession = {
                id: user.id,
                email: user.email,
                name: user.name,
                role: user.role,
                createdAt: user.createdAt
            };

            // Save to Local Storage
            localStorage.setItem(
                CONFIG.STORAGE_KEYS.USER, 
                JSON.stringify(userSession)
            );

            console.log('✅ Login successful:', userSession);
            Utils.showToast(`Welcome back, ${user.name}!`, 'success');

            return userSession;

        } catch (error) {
            console.error('❌ Login error:', error);
            Utils.showToast(Utils.formatError(error), 'error');
            throw error;
        }
    },

    /**
     * Register a new user
     * @param {object} userData - User registration data
     * @returns {Promise<object>} Created user object
     * @throws {Error} If validation fails or user already exists
     */
    async register(userData) {
        try {
            // Validate required fields
            if (!userData.email || !userData.password || !userData.name) {
                throw new Error('All fields are required');
            }

            // Validate email format
            if (!Utils.validateEmail(userData.email)) {
                throw new Error('Invalid email format');
            }

            // Validate password
            const passwordValidation = Utils.validatePassword(userData.password);
            if (!passwordValidation.isValid) {
                throw new Error(passwordValidation.message);
            }

            // Validate name length
            if (userData.name.length < CONFIG.VALIDATION.MIN_NAME_LENGTH) {
                throw new Error(`Name must be at least ${CONFIG.VALIDATION.MIN_NAME_LENGTH} characters long`);
            }

            console.log('Attempting registration for:', userData.email);

            // Check if user already exists
            const existingUsers = await API.get(CONFIG.ENDPOINTS.USERS);
            const userExists = existingUsers.some(
                u => u.email.toLowerCase() === userData.email.toLowerCase()
            );

            if (userExists) {
                throw new Error('A user with this email already exists');
            }

            // Create new user object
            const newUser = {
                email: userData.email.toLowerCase(),
                password: userData.password, // In production, this should be hashed
                name: userData.name.trim(),
                role: userData.role || CONFIG.ROLES.VISITOR, // Default to visitor
                createdAt: new Date().toISOString()
            };

            // Save user to API
            const createdUser = await API.post(CONFIG.ENDPOINTS.USERS, newUser);

            console.log('✅ Registration successful:', createdUser);
            Utils.showToast('Account created successfully! Please login.', 'success');

            return createdUser;

        } catch (error) {
            console.error('❌ Registration error:', error);
            Utils.showToast(Utils.formatError(error), 'error');
            throw error;
        }
    },

    /**
     * Logout the current user
     */
    logout() {
        try {
            const user = Utils.getCurrentUser();
            
            // Clear user session from Local Storage
            localStorage.removeItem(CONFIG.STORAGE_KEYS.USER);
            localStorage.removeItem(CONFIG.STORAGE_KEYS.SESSION);

            console.log('✅ User logged out:', user?.email);
            Utils.showToast('You have been logged out successfully', 'info');

            // Redirect to login page
            Router.navigate(CONFIG.ROUTES.LOGIN);

        } catch (error) {
            console.error('❌ Logout error:', error);
            Utils.showToast('Error during logout', 'error');
        }
    },

    /**
     * Check if user has required role
     * @param {string} requiredRole - Role to check for
     * @returns {boolean} True if user has the role
     */
    hasRole(requiredRole) {
        const user = Utils.getCurrentUser();
        return user && user.role === requiredRole;
    },

    /**
     * Check if current user can edit/delete an event
     * @param {object} event - Event object to check
     * @returns {boolean} True if user can modify the event
     */
    canModifyEvent(event) {
        const user = Utils.getCurrentUser();
        
        // Admin can modify any event
        if (user && user.role === CONFIG.ROLES.ADMIN) {
            return true;
        }

        // User can modify their own events
        if (user && event.createdBy === user.id) {
            return true;
        }

        return false;
    },

    /**
     * Require authentication - redirect to login if not authenticated
     * @returns {boolean} True if authenticated
     */
    requireAuth() {
        if (!Utils.isAuthenticated()) {
            console.warn('⚠ Authentication required - redirecting to login');
            Utils.showToast('Please login to continue', 'warning');
            Router.navigate(CONFIG.ROUTES.LOGIN);
            return false;
        }
        return true;
    },

    /**
     * Require admin role - show error if not admin
     * @returns {boolean} True if user is admin
     */
    requireAdmin() {
        if (!this.requireAuth()) {
            return false;
        }

        if (!Utils.isAdmin()) {
            console.warn('⚠ Admin access required');
            Utils.showToast('You do not have permission to access this page', 'error');
            Router.navigate(CONFIG.ROUTES.HOME);
            return false;
        }

        return true;
    },

    /**
     * Initialize authentication state on app load
     */
    init() {
        const user = Utils.getCurrentUser();
        if (user) {
            console.log('✅ User session restored:', user.email);
        } else {
            console.log('ℹ No active user session');
        }
    }
};

// Make Auth globally available
window.Auth = Auth;

console.log('✅ Authentication module loaded successfully');
