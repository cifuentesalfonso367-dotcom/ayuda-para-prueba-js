/**
 * ============================================
 * EVENTS MODULE - Component Functions Part 2
 * ============================================
 * 
 * This module extends the Components module with event-specific pages
 */

// Extend Components object with more methods
Object.assign(Components, {
    /**
     * Render events list page
     */
    async renderEventsList() {
        const app = this.getAppContainer();
        const user = Utils.getCurrentUser();
        
        try {
            const events = await API.getEvents();

            app.innerHTML = `
                ${this.renderNavbar()}
                <div class="container">
                    <div class="page-container">
                        <div class="page-header">
                            <h1 class="page-title">All Events</h1>
                            ${user.role === CONFIG.ROLES.ADMIN ? 
                                '<a href="/events/create" class="btn btn-primary">+ Create Event</a>' 
                                : ''
                            }
                        </div>

                        ${events.length > 0 ? `
                            <div class="grid grid-cols-2">
                                ${events.map(event => this.renderEventCard(event)).join('')}
                            </div>
                        ` : `
                            <div class="empty-state">
                                <div class="empty-state-icon">📅</div>
                                <h3 class="empty-state-title">No Events Available</h3>
                                <p class="empty-state-message">
                                    Check back later for new events!
                                </p>
                            </div>
                        `}
                    </div>
                </div>
            `;

        } catch (error) {
            console.error('Error rendering events list:', error);
            Utils.showToast('Error loading events', 'error');
        }
    },

    /**
     * Render single event detail page
     * @param {object} params - Route parameters (contains event id)
     */
    async renderEventDetail(params) {
        const app = this.getAppContainer();
        const user = Utils.getCurrentUser();
        
        try {
            const eventId = parseInt(params.id);
            const event = await API.getEvent(eventId);
            
            // Check if user is registered
            const isRegistered = await API.isRegistered(user.id, eventId);
            
            // Check if user can modify event
            const canModify = Auth.canModifyEvent(event);

            const capacityPercent = Utils.calculateCapacityPercentage(
                event.currentAttendees, 
                event.maxCapacity
            );
            const capacityStatus = Utils.getCapacityStatus(capacityPercent);
            
            const isFull = event.status === 'full';
            const isPast = Utils.isPastDate(event.date);

            app.innerHTML = `
                ${this.renderNavbar()}
                <div class="container">
                    <div class="page-container">
                        <a href="/events" class="btn btn-secondary mb-3">
                            ← Back to Events
                        </a>

                        <div class="card">
                            <div class="card-header">
                                <div>
                                    <span class="badge badge-primary">${event.category}</span>
                                    ${event.status === 'active' 
                                        ? '<span class="badge badge-success">Active</span>'
                                        : '<span class="badge badge-danger">Full</span>'
                                    }
                                </div>
                                ${canModify ? `
                                    <div class="flex gap-1">
                                        <a href="/events/edit/${event.id}" class="btn btn-warning btn-sm">
                                            ✏️ Edit
                                        </a>
                                        <button onclick="EventHandlers.deleteEvent(${event.id})" 
                                                class="btn btn-danger btn-sm">
                                            🗑️ Delete
                                        </button>
                                    </div>
                                ` : ''}
                            </div>

                            <h1 style="font-size: 2rem; margin-bottom: 1rem;">
                                ${Utils.sanitizeHTML(event.title)}
                            </h1>

                            <div class="event-meta mb-3">
                                <div class="event-meta-item" style="font-size: 1rem;">
                                    📅 ${Utils.formatDate(event.date)}
                                </div>
                                <div class="event-meta-item" style="font-size: 1rem;">
                                    🕐 ${Utils.formatTime(event.time)}
                                </div>
                                <div class="event-meta-item" style="font-size: 1rem;">
                                    📍 ${Utils.sanitizeHTML(event.location)}
                                </div>
                            </div>

                            <div class="mb-3">
                                <h3 style="margin-bottom: 0.5rem;">Description</h3>
                                <p style="line-height: 1.8; color: var(--text-secondary);">
                                    ${Utils.sanitizeHTML(event.description)}
                                </p>
                            </div>

                            <div class="mb-3">
                                <h3 style="margin-bottom: 0.5rem;">Capacity</h3>
                                <div class="event-capacity">
                                    <div class="capacity-bar">
                                        <div class="capacity-fill ${capacityStatus}" 
                                             style="width: ${capacityPercent}%"></div>
                                    </div>
                                    <span class="capacity-text" style="font-size: 1rem;">
                                        ${event.currentAttendees} / ${event.maxCapacity} attendees
                                        (${capacityPercent}% full)
                                    </span>
                                </div>
                            </div>

                            ${!canModify ? `
                                <div class="card-footer">
                                    ${isPast ? `
                                        <button class="btn btn-secondary" disabled>
                                            Event Has Ended
                                        </button>
                                    ` : isRegistered ? `
                                        <button onclick="EventHandlers.unregister(${event.id})" 
                                                class="btn btn-danger">
                                            Unregister from Event
                                        </button>
                                        <span class="badge badge-success" style="padding: 0.75rem 1rem;">
                                            ✓ You are registered
                                        </span>
                                    ` : isFull ? `
                                        <button class="btn btn-secondary" disabled>
                                            Event is Full
                                        </button>
                                    ` : `
                                        <button onclick="EventHandlers.register(${event.id})" 
                                                class="btn btn-success">
                                            Register for Event
                                        </button>
                                    `}
                                </div>
                            ` : ''}
                        </div>
                    </div>
                </div>
            `;

        } catch (error) {
            console.error('Error rendering event detail:', error);
            Utils.showToast('Error loading event details', 'error');
            Router.navigate('/events');
        }
    },

    /**
     * Render create event page
     */
    async renderCreateEvent() {
        const app = this.getAppContainer();
        
        app.innerHTML = `
            ${this.renderNavbar()}
            <div class="container">
                <div class="page-container">
                    <a href="/events" class="btn btn-secondary mb-3">
                        ← Back to Events
                    </a>

                    <h1 class="page-title">Create New Event</h1>

                    <form id="eventForm" class="card">
                        <div class="form-group">
                            <label for="title" class="form-label required">Event Title</label>
                            <input 
                                type="text" 
                                id="title" 
                                class="form-input" 
                                placeholder="e.g., JavaScript Workshop 2024"
                                required
                            >
                        </div>

                        <div class="form-group">
                            <label for="description" class="form-label required">Description</label>
                            <textarea 
                                id="description" 
                                class="form-textarea" 
                                placeholder="Describe your event..."
                                required
                            ></textarea>
                        </div>

                        <div class="grid grid-cols-2">
                            <div class="form-group">
                                <label for="date" class="form-label required">Date</label>
                                <input 
                                    type="date" 
                                    id="date" 
                                    class="form-input"
                                    min="${new Date().toISOString().split('T')[0]}"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label for="time" class="form-label required">Time</label>
                                <input 
                                    type="time" 
                                    id="time" 
                                    class="form-input"
                                    required
                                >
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="location" class="form-label required">Location</label>
                            <input 
                                type="text" 
                                id="location" 
                                class="form-input" 
                                placeholder="e.g., Tech Hub - Room 101"
                                required
                            >
                        </div>

                        <div class="grid grid-cols-2">
                            <div class="form-group">
                                <label for="category" class="form-label required">Category</label>
                                <select id="category" class="form-select" required>
                                    <option value="">Select a category</option>
                                    ${CONFIG.EVENT_CATEGORIES.map(cat => 
                                        `<option value="${cat}">${cat}</option>`
                                    ).join('')}
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="maxCapacity" class="form-label required">
                                    Max Capacity
                                </label>
                                <input 
                                    type="number" 
                                    id="maxCapacity" 
                                    class="form-input" 
                                    placeholder="e.g., 50"
                                    min="1"
                                    required
                                >
                                <span class="form-hint">
                                    Maximum number of attendees
                                </span>
                            </div>
                        </div>

                        <div class="flex gap-2 mt-3">
                            <button type="submit" class="btn btn-success">
                                Create Event
                            </button>
                            <a href="/events" class="btn btn-secondary">
                                Cancel
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        `;

        // Handle form submission
        document.getElementById('eventForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            await EventHandlers.createEvent();
        });
    },

    /**
     * Render edit event page
     * @param {object} params - Route parameters (contains event id)
     */
    async renderEditEvent(params) {
        const app = this.getAppContainer();
        
        try {
            const eventId = parseInt(params.id);
            const event = await API.getEvent(eventId);

            app.innerHTML = `
                ${this.renderNavbar()}
                <div class="container">
                    <div class="page-container">
                        <a href="/events/${event.id}" class="btn btn-secondary mb-3">
                            ← Back to Event
                        </a>

                        <h1 class="page-title">Edit Event</h1>

                        <form id="eventForm" class="card">
                            <div class="form-group">
                                <label for="title" class="form-label required">Event Title</label>
                                <input 
                                    type="text" 
                                    id="title" 
                                    class="form-input" 
                                    value="${Utils.sanitizeHTML(event.title)}"
                                    required
                                >
                            </div>

                            <div class="form-group">
                                <label for="description" class="form-label required">Description</label>
                                <textarea 
                                    id="description" 
                                    class="form-textarea"
                                    required
                                >${Utils.sanitizeHTML(event.description)}</textarea>
                            </div>

                            <div class="grid grid-cols-2">
                                <div class="form-group">
                                    <label for="date" class="form-label required">Date</label>
                                    <input 
                                        type="date" 
                                        id="date" 
                                        class="form-input"
                                        value="${event.date}"
                                        required
                                    >
                                </div>

                                <div class="form-group">
                                    <label for="time" class="form-label required">Time</label>
                                    <input 
                                        type="time" 
                                        id="time" 
                                        class="form-input"
                                        value="${event.time}"
                                        required
                                    >
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="location" class="form-label required">Location</label>
                                <input 
                                    type="text" 
                                    id="location" 
                                    class="form-input" 
                                    value="${Utils.sanitizeHTML(event.location)}"
                                    required
                                >
                            </div>

                            <div class="grid grid-cols-2">
                                <div class="form-group">
                                    <label for="category" class="form-label required">Category</label>
                                    <select id="category" class="form-select" required>
                                        ${CONFIG.EVENT_CATEGORIES.map(cat => 
                                            `<option value="${cat}" ${cat === event.category ? 'selected' : ''}>
                                                ${cat}
                                            </option>`
                                        ).join('')}
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label for="maxCapacity" class="form-label required">
                                        Max Capacity
                                    </label>
                                    <input 
                                        type="number" 
                                        id="maxCapacity" 
                                        class="form-input" 
                                        value="${event.maxCapacity}"
                                        min="${event.currentAttendees}"
                                        required
                                    >
                                    <span class="form-hint">
                                        Current attendees: ${event.currentAttendees}
                                    </span>
                                </div>
                            </div>

                            <div class="flex gap-2 mt-3">
                                <button type="submit" class="btn btn-warning">
                                    Save Changes
                                </button>
                                <a href="/events/${event.id}" class="btn btn-secondary">
                                    Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            `;

            // Handle form submission
            document.getElementById('eventForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                await EventHandlers.updateEvent(eventId, event);
            });

        } catch (error) {
            console.error('Error rendering edit event:', error);
            Utils.showToast('Error loading event', 'error');
            Router.navigate('/events');
        }
    },

    /**
     * Render my events page (events user is registered for)
     */
    async renderMyEvents() {
        const app = this.getAppContainer();
        const user = Utils.getCurrentUser();
        
        try {
            const myEvents = await API.getUserRegistrations(user.id);

            app.innerHTML = `
                ${this.renderNavbar()}
                <div class="container">
                    <div class="page-container">
                        <div class="page-header">
                            <h1 class="page-title">My Registered Events</h1>
                            <a href="/events" class="btn btn-primary">Browse More Events</a>
                        </div>

                        ${myEvents.length > 0 ? `
                            <div class="grid grid-cols-2">
                                ${myEvents.map(event => this.renderEventCard(event)).join('')}
                            </div>
                        ` : `
                            <div class="empty-state">
                                <div class="empty-state-icon">🎫</div>
                                <h3 class="empty-state-title">No Registered Events</h3>
                                <p class="empty-state-message">
                                    You haven't registered for any events yet.
                                    Browse available events and register!
                                </p>
                                <a href="/events" class="btn btn-primary">
                                    Browse Events
                                </a>
                            </div>
                        `}
                    </div>
                </div>
            `;

        } catch (error) {
            console.error('Error rendering my events:', error);
            Utils.showToast('Error loading your events', 'error');
        }
    }
});

/**
 * Event handlers for form submissions and actions
 */
const EventHandlers = {
    /**
     * Create a new event
     */
    async createEvent() {
        try {
            const user = Utils.getCurrentUser();
            
            // Collect form data
            const eventData = {
                title: document.getElementById('title').value.trim(),
                description: document.getElementById('description').value.trim(),
                date: document.getElementById('date').value,
                time: document.getElementById('time').value,
                location: document.getElementById('location').value.trim(),
                category: document.getElementById('category').value,
                maxCapacity: parseInt(document.getElementById('maxCapacity').value),
                currentAttendees: 0,
                status: 'active',
                createdBy: user.id,
                createdAt: new Date().toISOString()
            };

            // Validate
            if (eventData.maxCapacity < 1) {
                throw new Error('Max capacity must be at least 1');
            }

            // Create event via API
            await API.createEvent(eventData);
            
            Utils.showToast('Event created successfully!', 'success');
            Router.navigate('/events');

        } catch (error) {
            console.error('Error creating event:', error);
            Utils.showToast(Utils.formatError(error), 'error');
        }
    },

    /**
     * Update an existing event
     * @param {number} eventId - Event ID
     * @param {object} originalEvent - Original event data
     */
    async updateEvent(eventId, originalEvent) {
        try {
            // Collect form data
            const eventData = {
                ...originalEvent,
                title: document.getElementById('title').value.trim(),
                description: document.getElementById('description').value.trim(),
                date: document.getElementById('date').value,
                time: document.getElementById('time').value,
                location: document.getElementById('location').value.trim(),
                category: document.getElementById('category').value,
                maxCapacity: parseInt(document.getElementById('maxCapacity').value)
            };

            // Validate
            if (eventData.maxCapacity < eventData.currentAttendees) {
                throw new Error('Max capacity cannot be less than current attendees');
            }

            // Update status if capacity changed
            if (eventData.currentAttendees >= eventData.maxCapacity) {
                eventData.status = 'full';
            } else {
                eventData.status = 'active';
            }

            // Update event via API
            await API.updateEvent(eventId, eventData);
            
            Utils.showToast('Event updated successfully!', 'success');
            Router.navigate(`/events/${eventId}`);

        } catch (error) {
            console.error('Error updating event:', error);
            Utils.showToast(Utils.formatError(error), 'error');
        }
    },

    /**
     * Delete an event
     * @param {number} eventId - Event ID
     */
    async deleteEvent(eventId) {
        if (!confirm('Are you sure you want to delete this event? This action cannot be undone.')) {
            return;
        }

        try {
            await API.deleteEvent(eventId);
            Utils.showToast('Event deleted successfully', 'success');
            Router.navigate('/events');

        } catch (error) {
            console.error('Error deleting event:', error);
            Utils.showToast('Error deleting event', 'error');
        }
    },

    /**
     * Register for an event
     * @param {number} eventId - Event ID
     */
    async register(eventId) {
        try {
            const user = Utils.getCurrentUser();
            await API.registerForEvent(user.id, eventId);
            
            Utils.showToast('Successfully registered for event!', 'success');
            Router.reload(); // Reload current page

        } catch (error) {
            console.error('Error registering:', error);
            Utils.showToast(Utils.formatError(error), 'error');
        }
    },

    /**
     * Unregister from an event
     * @param {number} eventId - Event ID
     */
    async unregister(eventId) {
        if (!confirm('Are you sure you want to unregister from this event?')) {
            return;
        }

        try {
            const user = Utils.getCurrentUser();
            await API.unregisterFromEvent(user.id, eventId);
            
            Utils.showToast('Successfully unregistered from event', 'info');
            Router.reload(); // Reload current page

        } catch (error) {
            console.error('Error unregistering:', error);
            Utils.showToast(Utils.formatError(error), 'error');
        }
    }
};

// Make EventHandlers globally available
window.EventHandlers = EventHandlers;

console.log('✅ Events module loaded (Part 2)');
