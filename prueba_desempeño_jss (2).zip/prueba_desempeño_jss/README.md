# 🎉 Event Management System - Single Page Application

A comprehensive event management system built with vanilla JavaScript, featuring user authentication, role-based access control, CRUD operations, and real-time capacity tracking.

## 📋 Table of Contents

- [Features](#features)
- [Technologies](#technologies)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Usage](#usage)
- [API Endpoints](#api-endpoints)
- [User Roles](#user-roles)
- [Architecture](#architecture)
- [Screenshots](#screenshots)
- [Developer Information](#developer-information)

## ✨ Features

### Authentication & Authorization
- ✅ User registration with email validation
- ✅ Secure login system
- ✅ Role-based access control (Admin & Visitor)
- ✅ Session persistence using Local Storage
- ✅ Protected routes with automatic redirection

### Event Management (Admin Only)
- ✅ Create new events with comprehensive details
- ✅ Edit existing events
- ✅ Delete events with confirmation
- ✅ Automatic capacity management
- ✅ Event status tracking (Active/Full)

### Event Discovery & Registration (All Users)
- ✅ Browse all available events
- ✅ View detailed event information
- ✅ Register for events
- ✅ Unregister from events
- ✅ View personal registered events
- ✅ Real-time capacity indicators
- ✅ Event categories and filtering

### Technical Features
- ✅ Single Page Application (No page reloads)
- ✅ Dynamic routing with URL parameters
- ✅ RESTful API integration using Fetch API
- ✅ Error handling with try...catch
- ✅ Input validation and sanitization
- ✅ Toast notifications for user feedback
- ✅ Responsive design for all devices
- ✅ Loading states and animations

## 🛠️ Technologies

- **Frontend**: Vanilla JavaScript (ES6+), HTML5, CSS3
- **Backend Simulation**: json-server
- **Storage**: Local Storage for session persistence
- **Architecture**: SPA with client-side routing
- **API Communication**: Fetch API with async/await
- **Design Pattern**: Modular JavaScript with separation of concerns

## 📁 Project Structure

```
event-management-system/
│
├── index.html              # Main HTML file (SPA container)
├── styles.css              # Complete styling
├── db.json                 # json-server database
│
├── js/
│   ├── config.js          # Configuration constants
│   ├── utils.js           # Utility functions
│   ├── auth.js            # Authentication module
│   ├── api.js             # API communication layer
│   ├── router.js          # SPA routing system
│   ├── components.js      # UI components (Part 1)
│   ├── events.js          # Event components (Part 2)
│   └── app.js             # Application entry point
│
└── README.md              # This file
```

## 🚀 Installation

### Prerequisites

- **Node.js** (version 18 or higher)
- **npm** (comes with Node.js)
- **Modern web browser** (Chrome, Firefox, Edge, Safari)
- **Code editor** (VS Code recommended)

### Step 1: Install json-server

Open your terminal and run:

```bash
npm install -g json-server
```

Verify installation:

```bash
json-server --version
```

### Step 2: Start json-server

Navigate to the project directory and run:

```bash
json-server --watch db.json --port 3000
```

You should see output like:

```
Resources
http://localhost:3000/users
http://localhost:3000/events
http://localhost:3000/registrations

Home
http://localhost:3000
```

**Keep this terminal window open!** The server must be running for the application to work.

### Step 3: Serve the Application

You have several options to serve the HTML files:

#### Option A: Live Server (VS Code Extension)
1. Install "Live Server" extension in VS Code
2. Right-click on `index.html`
3. Select "Open with Live Server"
4. Browser opens automatically at `http://localhost:5500`

#### Option B: Python HTTP Server
```bash
# Python 3
python -m http.server 8000

# Then open: http://localhost:8000
```

#### Option C: Node.js http-server
```bash
# Install globally
npm install -g http-server

# Run in project directory
http-server

# Open: http://localhost:8080
```

**Important**: Do NOT open `index.html` directly as a file (file://). This will cause CORS errors with the API.

## 📖 Usage

### Demo Credentials

The system comes with pre-configured demo accounts:

**Administrator Account:**
- Email: `admin@events.com`
- Password: `Admin123!`
- Capabilities: Full access - create, edit, delete events

**Visitor Account:**
- Email: `user@events.com`
- Password: `User123!`
- Capabilities: View and register for events

### Creating a New Account

1. Click "Register here" on the login page
2. Fill in your details:
   - Full Name (minimum 3 characters)
   - Email (valid format required)
   - Password (minimum 6 characters)
   - Role (Visitor or Admin)
3. Click "Create Account"
4. Login with your new credentials

### Managing Events (Admin Only)

#### Creating an Event
1. Login as admin
2. Click "Create Event" button
3. Fill in event details:
   - Title
   - Description
   - Date and Time
   - Location
   - Category
   - Max Capacity
4. Click "Create Event"

#### Editing an Event
1. Navigate to event detail page
2. Click "Edit" button (only visible to admins)
3. Modify desired fields
4. Click "Save Changes"

#### Deleting an Event
1. Navigate to event detail page
2. Click "Delete" button (only visible to admins)
3. Confirm deletion

### Registering for Events (All Users)

1. Browse events on the Events page
2. Click "View Details" on any event
3. Click "Register for Event" button
4. Confirmation message appears
5. View your registrations in "My Events"

### Capacity Management

- Events automatically track registered attendees
- Visual progress bars show capacity percentage
- Events marked as "Full" when at max capacity
- Users cannot register for full events
- Unregistering frees up a spot

## 🔌 API Endpoints

### Users
- `GET /users` - Get all users
- `GET /users/:id` - Get user by ID
- `POST /users` - Create new user
- `PUT /users/:id` - Update user
- `DELETE /users/:id` - Delete user

### Events
- `GET /events` - Get all events
- `GET /events/:id` - Get event by ID
- `POST /events` - Create new event
- `PUT /events/:id` - Update event
- `DELETE /events/:id` - Delete event

### Registrations
- `GET /registrations` - Get all registrations
- `GET /registrations?userId=:id` - Get user registrations
- `GET /registrations?eventId=:id` - Get event registrations
- `POST /registrations` - Create registration
- `DELETE /registrations/:id` - Delete registration

## 👥 User Roles

### Admin
- Can create new events
- Can edit any event
- Can delete any event
- Can view all events
- Can register for events
- Full access to the system

### Visitor
- Can view all events
- Can register for events
- Can unregister from events
- Can view their registered events
- Cannot create, edit, or delete events

## 🏗️ Architecture

### Module Organization

#### config.js
- Application configuration
- API endpoints
- Storage keys
- Validation rules
- Constants

#### utils.js
- Toast notifications
- Date/time formatting
- Validation functions
- Helper utilities
- Common operations

#### auth.js
- User login
- User registration
- Session management
- Role checking
- Access control

#### api.js
- Fetch wrapper
- CRUD operations
- Error handling
- Request/response management
- Event registration logic

#### router.js
- Client-side routing
- Route protection
- Dynamic parameters
- Navigation handling
- History management

#### components.js
- UI rendering
- Page components
- Reusable elements
- Form handling
- Event cards

#### events.js
- Event-specific pages
- Event creation
- Event editing
- Registration handling
- Capacity management

#### app.js
- Application initialization
- Module coordination
- Error boundaries
- Startup procedures

### Data Flow

```
User Action → Component → API Module → json-server
                ↓              ↓
           Router ← Utils ← Response
                ↓
           Re-render
```

### State Management

- **Local Storage**: User session persistence
- **json-server**: Central data store
- **Component State**: Temporary UI state
- **Router State**: Current route and parameters

## 🖼️ Screenshots

### Login Page
User authentication with email and password validation.

### Home Dashboard
Overview with statistics and quick actions.

### Events List
Grid view of all available events with capacity indicators.

### Event Details
Comprehensive event information with registration option.

### Create Event (Admin)
Form for creating new events with validation.

### My Events
Personal list of registered events.

## 👨‍💻 Developer Information

**Project**: Event Management System - SPA
**Type**: JavaScript Training Assessment
**Framework**: Vanilla JavaScript (No frameworks)
**Assessment Focus**: 
- DOM Manipulation
- API Integration
- Authentication
- Routing
- CRUD Operations
- Error Handling

### Key Learning Outcomes

1. **SPA Architecture**: Understanding client-side routing and state management
2. **API Integration**: Working with RESTful APIs using Fetch
3. **Authentication**: Implementing secure login and session management
4. **CRUD Operations**: Complete Create, Read, Update, Delete functionality
5. **Error Handling**: Comprehensive try...catch implementation
6. **Code Organization**: Modular JavaScript with separation of concerns
7. **User Experience**: Loading states, validations, and feedback
8. **Responsive Design**: Mobile-first approach with modern CSS

### Code Quality

- ✅ 100% English code and comments
- ✅ Comprehensive inline documentation
- ✅ Consistent naming conventions
- ✅ Error handling on all async operations
- ✅ Input validation and sanitization
- ✅ Modular and maintainable structure
- ✅ DRY principle applied throughout
- ✅ No console errors in production

## 🐛 Troubleshooting

### Common Issues

**Issue**: "Cannot connect to server" error
**Solution**: Make sure json-server is running on port 3000

**Issue**: CORS errors in console
**Solution**: Don't open index.html as a file, use a local server

**Issue**: Changes not saving
**Solution**: Check json-server terminal for errors

**Issue**: Page shows blank
**Solution**: Open browser DevTools console to see error messages

**Issue**: Login not working
**Solution**: Verify db.json has user data and json-server is running

### Debug Mode

Open browser console (F12) to see detailed logs:
- API requests and responses
- Authentication status
- Routing events
- Error messages

## 📝 License

This project is created for educational purposes as part of JavaScript training assessment.

## 🙏 Acknowledgments

- RIWI Training Program
- json-server for easy API simulation
- Modern JavaScript best practices

---

**Last Updated**: February 2024
**Version**: 1.0.0
**Status**: Production Ready ✅

For questions or issues, please refer to the troubleshooting section or check the browser console for detailed error messages.
